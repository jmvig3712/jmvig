import java.util.*;
class Main {
  public static void main(String[] args) {
    Random dieRoll = new Random();
    System.out.println("Hello, please input the desired number of sides: ");
    Scanner sideScan = new Scanner(System.in);
    int numSides = sideScan.nextInt();
    ArrayList<Integer> myRolls = new ArrayList();
    for(int i = 0; i < 99; i++){
      int currValue = dieRoll.nextInt(numSides)+1;
      myRolls.add(i, currValue);
    }
    Collections.sort(myRolls);
    System.out.println(myRolls);
    double median = (myRolls.get(50) + myRolls.get(51)/2);
    System.out.println("The median is:" + median);
    int sum = 0;
    for(Integer roll : myRolls){
      sum += roll;
    }
    double average = sum/100;
  System.out.println("The average is:" + average);

  int c1 = 0;
 int c2 = 0;
 int c3 = 0;
 int c4 = 0;
 int c5 = 0;
 int c6 = 0;
 for(int i=0; i<myRolls.size();i++){
   if(myRolls.get(i) == 1){
     c1+=1;
   }
   if(myRolls.get(i) == 2){
     c2+=1;
   }
    if(myRolls.get(i) == 3){
     c3+=1;
   }
    if(myRolls.get(i) == 4){
     c4+=1;
   }
    if(myRolls.get(i) == 5){
     c5+=1;
   }
    if(myRolls.get(i) == 6){
     c6+=1;
   }
 }
 System.out.println("The number 1 was rolled "+c1+" times");
 System.out.println("The number 2 was rolled "+c2+" times");
 System.out.println("The number 3 was rolled "+c3+" times");
 System.out.println("The number 4 was rolled "+c4+" times");
 System.out.println("The number 5 was rolled "+c5+" times");
 System.out.println("The number 6 was rolled "+c6+" times");



  }
}